export type Tomtest0412Auth = any; // No Authentication
