import { HttpHeaders } from "@trayio/commons/http/Http";

export type RawHttpRequestOutput = {
  status: number;
  headers: HttpHeaders;
  body: string | number | boolean | null | object | Array<any>;
};
