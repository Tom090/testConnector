/**
 * @title raw
 * @description The raw body to perform the request with.
 */
export type RawBodyType = {
	/**
	 * @title raw
	 * @description Select either `string` to send the body as defined, or `object` to send the body as a JSON object.
	 * @dropdown false
	 * @format code
	 */
	raw: string | object;
};

// /**
//  * @title File
//  * @format file
//  */
// export type FormDataFileType = object;

// /**
//  * @title Text
//  * @description A text value for the property in the form data body.
//  */
// export type FormDataStringType = string;

// /**
//  * @title form-data
//  * @description The form data to perform the request with.
//  */
// export type FormDataBodyType = {
//   /**
//    * @title form-data
//    * @description The form data to send with the request.
//    */
//   formData: {
//     [key: string]: FormDataStringType | FormDataFileType;
//   };
// };

/**
 * @title form-urlencoded
 * @description The form urlencoded body to perform the request with.
 */
export type FormUrlEncodedBodyType = {
	/**
	 * @title form-urlencoded
	 * @description The form urlencoded data to send with the request.
	 * @additionalProperties { "type": "string" }
	 */
	form_urlencoded: object;
};

/**
 * @title binary
 * @description The binary body to perform the request with.
 * @additionalProperties false
 */
export type BinaryBodyType = {
	/**
	 * @title binary
	 * @description The tray file object to retrieve the contents of and send with the request.
	 * @format file
	 * @additionalProperties false
	 */
	binary: {};
};

/**
 * @title none
 * @description Select this option to not send a body in the request.
 */
export type NoneBodyType = {
	/**
	 * @title None
	 * @description Select this option to not send a body in the request.
	 */
	none: null;
};

/**
 * @title Endpoint
 */
export type Endpoint = {
	/**
	 * @title Endpoint
	 * @description The endpoint to call in relation to the base URL used by the connector. E.g: '/department/marketing/employees'.
	 */
	endpoint: string;
};

/**
 * @title Full URL
 */
export type FullUrl = {
	/**
	 * @title Full URL
	 * @description The full URL to make the request against. Must begin with `http://` or `https://`.
	 */
	fullUrl: string;
};

export enum HttpMethod {
	Delete = 'DELETE',
	Get = 'GET',
	Head = 'HEAD',
	Options = 'OPTIONS',
	Patch = 'PATCH',
	Post = 'POST',
	Put = 'PUT',
}

export type RawHttpRequestInput = {
	/**
	 * @title Method
	 * @description The HTTP verb to perform the request with.
	 * @default GET
	 * @enumLabels DELETE, GET, HEAD, OPTIONS, PATCH, POST, PUT
	 */
	method: HttpMethod;

	/**
	 * @title URL
	 * @description The URL to make the request with.
	 */
	url: Endpoint | FullUrl;

	/**
	 * @title Headers
	 * @description Headers to include in the request.
	 */
	headers?: object;

	/**
	 * @title Query Params
	 * @description Query parameters to be supplied with the request.
	 */
	queryParams?: object;

	/**
	 * @title Body Type
	 * @description The body of the request.
	 */
	body: RawBodyType | FormUrlEncodedBodyType | BinaryBodyType | NoneBodyType;
};
