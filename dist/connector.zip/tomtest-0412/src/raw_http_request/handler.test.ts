import { OperationHandlerTestSetup } from '@trayio/cdk-dsl/connector/operation/OperationHandlerTest';
import { OperationHandlerResult } from '@trayio/cdk-dsl/connector/operation/OperationHandler';
import { HttpMethod } from '@trayio/commons/http/Http';
import { RawHttpRequestCdkHandler } from './handler';

import '@trayio/cdk-runtime/connector/operation/OperationHandlerTestRunner';

OperationHandlerTestSetup.configureHandlerTest(
	RawHttpRequestCdkHandler,
	(handlerTest) =>
		handlerTest
			.usingHandlerContext('test')
			.nothingBeforeAll()
			.testCase('should do something', (testCase) =>
				testCase
					.givenNothing()
					.when(() => ({
						method: HttpMethod.Get,
						url: { endpoint: '/posts' },
						headers: {},
						queryParams: {},
						body: { none: null },
					}))
					.then(({ output }) => {
						const outputValue =
							OperationHandlerResult.getSuccessfulValueOrFail(output);
					})
					.finallyDoNothing()
			)
			.nothingAfterAll()
);
