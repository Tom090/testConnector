export type GetPostInput = {
	id: number;
};
